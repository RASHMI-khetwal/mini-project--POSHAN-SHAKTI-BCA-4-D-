import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Poshan Shakti - Database Connection
 *
 * SECURITY: Your password was exposed in the original file!
 * Option 1 (Simple): Update the password string below
 * Option 2 (Better): Set an environment variable called DB_PASS
 *   - Windows: setx DB_PASS "your_password"
 *   - Linux/Mac: export DB_PASS="your_password"
 *
 * Database must be running on MySQL at localhost:3306
 * Database name: poshan_shakti
 * See HOW_TO_RUN.md for full setup instructions
 */
public class DBConnection {

    private static final String DB_URL  = "jdbc:mysql://localhost:3306/poshan_shakti?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";

    // TODO: Replace with your MySQL password, OR use environment variable
    private static final String DB_PASS = System.getenv("DB_PASS") != null
                                        ? System.getenv("DB_PASS")
                                        : "YourPasswordHere";  // <-- change this

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
        } catch (Exception e) {
            System.err.println("DB Connection Failed: " + e.getMessage());
            e.printStackTrace();
        }
        return con;
    }
}
