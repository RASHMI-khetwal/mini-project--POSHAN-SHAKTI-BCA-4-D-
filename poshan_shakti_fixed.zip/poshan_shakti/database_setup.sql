-- ============================================================
-- POSHAN SHAKTI - Database Setup Script
-- Run this in MySQL Workbench or MySQL Command Line
-- ============================================================

-- Step 1: Create the database
CREATE DATABASE IF NOT EXISTS poshan_shakti;
USE poshan_shakti;

-- ============================================================
-- TABLE 1: NGO Login Users
-- ============================================================
CREATE TABLE IF NOT EXISTS ngo_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    ngo_name VARCHAR(100),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert a default admin user (username: admin, password: poshan123)
INSERT INTO ngo_users (username, password, ngo_name, email)
VALUES ('admin', 'poshan123', 'Poshan Shakti NGO', 'admin@poshan.org')
ON DUPLICATE KEY UPDATE username = username;

-- ============================================================
-- TABLE 2: Students
-- ============================================================
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT,
    gender VARCHAR(10),
    class_name VARCHAR(20),
    roll_number VARCHAR(20),
    height_cm DECIMAL(5,1),
    weight_kg DECIMAL(5,1),
    bmi DECIMAL(4,1),
    school_name VARCHAR(150),
    parent_contact VARCHAR(15),
    date_added DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 3: Mid Day Meal Log
-- ============================================================
CREATE TABLE IF NOT EXISTS meal_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    meal_date DATE NOT NULL,
    class_name VARCHAR(20),
    students_fed INT,
    food_items TEXT,        -- stored as comma separated list
    total_calories INT,
    total_protein DECIMAL(6,2),
    total_carb DECIMAL(6,2),
    total_fat DECIMAL(6,2),
    logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE 4: Donations
-- ============================================================
CREATE TABLE IF NOT EXISTS donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donor_name VARCHAR(100) NOT NULL,
    phone VARCHAR(15),
    email VARCHAR(100),
    donation_type VARCHAR(20),   -- 'Money', 'Food', 'Other'
    amount DECIMAL(10,2),
    details TEXT,
    message TEXT,
    donation_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- VIEW: BMI Summary (useful for reports)
-- ============================================================
CREATE OR REPLACE VIEW bmi_summary AS
SELECT
    CASE
        WHEN bmi < 14   THEN 'Severely Underweight'
        WHEN bmi < 18.5 THEN 'Underweight'
        WHEN bmi < 25   THEN 'Normal'
        ELSE 'Overweight'
    END AS bmi_status,
    COUNT(*) AS student_count
FROM students
GROUP BY bmi_status;

-- ============================================================
-- VERIFY: Check tables were created
-- ============================================================
SHOW TABLES;
SELECT 'Database setup complete!' AS status;
