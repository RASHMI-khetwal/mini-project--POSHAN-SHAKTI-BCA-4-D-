# 🌱 POSHAN SHAKTI — How To Run This Website Locally
## (Complete Beginner Guide — Zero Coding Knowledge Needed)

---

## ✅ OPTION A: Run WITHOUT Tomcat (Recommended for beginners!)
### The website now works FULLY in your browser without any server!

All 4 modules (Students, Nutrition, Mid Day Meal, Donations) work using
your browser's built-in storage. No Java, no Tomcat, no database needed.

**Steps:**
1. Extract the zip file to your Desktop
2. Open the `poshan_shakti` folder
3. Double-click `index.html`
4. The website opens in your browser — done! ✅

> ⚠️ This is perfect for testing and using the app.
> The only thing that won't work without Tomcat is the LOGIN button
> (it uses demo login: username = admin, password = poshan123)

---

## 🖥️ OPTION B: Run WITH Tomcat (for real Java + MySQL backend)

### What you need to install first:
1. **Java JDK 11 or higher** → https://adoptium.net
2. **Apache Tomcat 10** → https://tomcat.apache.org
3. **MySQL** → https://dev.mysql.com/downloads/mysql/
4. **VS Code** → already have it ✅

---

### STEP 1: Install Java JDK
1. Go to https://adoptium.net
2. Download "Temurin 17 (LTS)" for Windows
3. Run the installer, click Next → Next → Finish
4. To verify: open Command Prompt (Win+R → type cmd → Enter)
5. Type: `java -version` and press Enter
6. You should see: `openjdk version "17.x.x ..."`

---

### STEP 2: Install Tomcat
1. Go to https://tomcat.apache.org → Click "Tomcat 10" → "64-bit Windows zip"
2. Extract the zip (e.g., to `C:\apache-tomcat-10.x`)
3. That's it! Tomcat doesn't need installation.

---

### STEP 3: Set Up MySQL Database
1. Install MySQL from https://dev.mysql.com/downloads/mysql/
2. During setup, set root password — REMEMBER THIS PASSWORD
3. Update `DBConnection.java` line 21: replace `YourPasswordHere` with your password
4. Open MySQL Workbench (installed automatically with MySQL)
5. Connect to Local instance
6. Click File → Open SQL Script → select `database_setup.sql` from this folder
7. Press Ctrl+Shift+Enter to run all
8. You should see all tables created ✅

---

### STEP 4: Deploy to Tomcat
1. Copy the entire `poshan_shakti` folder into:
   ```
   C:\apache-tomcat-10.x\webapps\poshan_shakti\
   ```
   So the structure looks like:
   ```
   webapps\
     poshan_shakti\
       index.html
       students.html
       ...
       WEB-INF\
         web.xml
         classes\
         lib\
   ```

2. Compile the Java files. Open Command Prompt:
   ```
   cd C:\apache-tomcat-10.x\webapps\poshan_shakti
   
   javac -cp "WEB-INF\lib\mysql-connector-j-9.6.0.jar;C:\apache-tomcat-10.x\lib\servlet-api.jar" -d WEB-INF\classes WEB-INF\classes\DBConnection.java WEB-INF\classes\LoginServlet.java
   ```

3. Start Tomcat. Open Command Prompt:
   ```
   cd C:\apache-tomcat-10.x\bin
   startup.bat
   ```
   A new window opens — wait for "Server startup in X ms"

4. Open your browser and go to:
   ```
   http://localhost:8080/poshan_shakti/
   ```

5. You should see the Poshan Shakti homepage! ✅

---

### STEP 5: Login Works!
- Go to http://localhost:8080/poshan_shakti/login.html
- Username: `admin`
- Password: `poshan123`

---

## ❓ TROUBLESHOOTING

| Problem | Fix |
|---------|-----|
| 404 error | Make sure the folder is named exactly `poshan_shakti` inside `webapps` |
| Can't compile Java | Make sure Java JDK is installed and `javac` is in PATH |
| Database error | Check MySQL is running, password is correct in DBConnection.java |
| Tomcat won't start | Port 8080 may be in use. Restart your PC and try again |
| Login not working | Use demo: admin / poshan123 |

---

## 📱 WHAT EACH PAGE DOES

| Page | File | What you can do |
|------|------|-----------------|
| Home | index.html | Overview and quick stats |
| Students | students.html | Add/delete students with height, weight, BMI |
| Mid Day Meal | midday.html | Log daily meals (roti, sabzi, milk, egg etc.) |
| Nutrition | nutrition.html | See BMI analysis, calorie charts, health alerts |
| Donation | donation.html | Record money or food donations |
| Login | login.html | NGO admin login |

---

## 🔒 SECURITY REMINDER
Your original code had your MySQL password visible!
**Please change your MySQL root password** since it was exposed in the zip file.
To change MySQL password:
1. Open MySQL Workbench
2. Go to Server → Users and Privileges
3. Select root → Change Password

---
Made for Poshan Shakti NGO — Mid Day Meal Tracker 🌱
